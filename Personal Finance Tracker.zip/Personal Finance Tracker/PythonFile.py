# Author - Pavithran Francis
# Semester 01
# Computer Science
# SD1 Coursework 3
# IIT ID - 20231013
# UoW ID - w2084832

from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from tkinter import filedialog
from Sub import *
import json
import datetime
import string

# File name is defined at the top to be accessible by the entire program and can be easily changed
file_name = "PFT Transactions.json"

# Function to load the transactions from the JSON file
def load_transactions(file_name):
    """This function loads transactions from a preexisting file
    and if no file exits it would return an empty dictionary"""
    global transactions  # Transactions defined as global variable for continuous updates

    # Try and except function to open a file
    try:
        with open(file_name, 'r') as file:
            transactions = json.load(file)
            return transactions

    # If there is no file a new file will be created informing the user
    except FileNotFoundError:
        with open(file_name, 'w') as file:
            messagebox.showinfo("Non-existing base file",
                                "Base file not found \n A new file is created")
        return {}

    # If the JSON file is empty or scrambled it will simply return an empty dictionary
    except json.JSONDecodeError:
        messagebox.showinfo("JSON data scrambled",
                            "Base file cannot be decoded or empty\nTransactions will be recorded after any updates")
        return {}

    # Additional error for safety reason for instances where there is no primary memory capacity
    except MemoryError:
        messagebox.showinfo("Memory Error",
                            "Try clearing cache memory and try again \n or deleting a few files")
        exit()

    # To show the user any other error which might have occurred for the user to debug
    except Exception as e:
        messagebox.showinfo("Error", str(e))
        exit()


# Function to save transactions from the running program
# This save function will only be reflected after the program is terminated
# Till then the updated data will be stored in a buffer
def save_transactions(file_name):
    """This function saves transactions into the JSON file after the user exits the program"""

    global transactions  # Defining transactions as global variable for continuous editing

    # Try and except function for even write mode as still some errors might occur
    try:
        with open(file_name, 'w') as file:
            json.dump(transactions, file, indent=4)

    # There can be an instance where the user might move the python file to a different location while running
    # Or there can be a lag in the computer system
    except FileNotFoundError:
        messagebox.showerror("File not found",
                             "Try restarting your device and try again")
        exit()

    # This is for instances when JSON files are scrambled and unable to load data in it
    except json.JSONDecodeError:
        messagebox.showerror("JSON data scrambled",
                             f"try deleting {file_name} and try again")
        exit()

    # For instances when there is no storage space to create a new file
    except MemoryError:
        messagebox.showerror("Memory Error",
                             "Try clearing cache memory and try again or deleting a few files")
        exit()

    # To show the user an accurate message for any other error which might occur
    except Exception as e:
        messagebox.showinfo("Error", str(e))
        exit()


# A program to quit the GUI gracefully with an ok or cancel message box option
# This is activated if the button on the left top corner is pressed on any other formatted windows
def exit_gui():
    """This function exits the program in a user-friendly manner"""
    exit_variable = messagebox.askokcancel("Quit", "Do you want to quit?")

    # Only if the user gives ok the GUI would close
    if exit_variable:
        messagebox.showinfo("Thankyou", "Thankyou for using personal finance tracker")
        window.destroy()

    else:
        return


# Function to delete transactions from the tree view
def delete_from_treeview(my_tree):
    """This function deletes transactions from the tree view using the loaded argument
    and returns the transactions after deleting them"""
    global transactions
    global count  # Count if defined as a global variable to identify transaction iid's

    selected_fields = my_tree.selection()

    for item in selected_fields:
        my_tree.delete(item)

    transaction_list = []

    for category, transaction in transactions.items():
        for trans in transaction:
            amount = trans["Amount"]
            transaction_type = trans["Transaction Type"]
            date = trans["Date"]
            transaction_list.append([category, amount, transaction_type, date])

    updated_transaction_list = transaction_list.copy()

    for i in sorted(map(int, selected_fields), reverse=True):
        if 0 <= i < len(updated_transaction_list):
            del updated_transaction_list[i]

    my_tree.delete(*my_tree.get_children())  # Clear the Treeview widget
    for i, trans in enumerate(updated_transaction_list, start=1):
        my_tree.insert("", "end", text=f"Item-{i}", values=trans)


    transactions = {}
    for category, amount, transaction_type, date in updated_transaction_list:
        transactions.setdefault(category, []).append({
            "Amount": amount,
            "Transaction Type": transaction_type,
            "Date": date,
        })

    save_transactions(file_name)

    messagebox.showinfo("Success", "Transactions deleted")

    delete_transaction()
    return


def sort_treeview(tree, column, current_sort_order):
    """This function sorts the tree view using the loaded arguments in ascending and descending order
    for all column headings and allows double-clicking on each column as well"""
    if column == "Category":
        data = [(tree.set(child, column), child) for child in tree.get_children('')]

        data.sort(key=lambda x: str(x[0]).lower(), reverse=(current_sort_order == "desc"))

        for idx, item in enumerate(data):
            tree.move(item[1], '', idx)

    elif column == "Amount":
        data = [(float(tree.set(child, column)), child) for child in tree.get_children('')]

        data.sort(reverse=(current_sort_order == "desc"))

        for idx, item in enumerate(data):
            tree.move(item[1], '', idx)

    else:
        data = [(tree.set(child, column), child) for child in tree.get_children('')]

        data.sort(key=lambda x: str(x[0]).lower(), reverse=(current_sort_order == "desc"))

        for idx, item in enumerate(data):
            tree.move(item[1], '', idx)

    new_sort_order = "asc" if current_sort_order == "desc" else "desc"

    tree.heading(column, text=column, anchor=CENTER, command=lambda: sort_treeview(tree, column, new_sort_order))


def search_transactions(tree, search_entry):
    """This function would allow you to search for an item in the tree
    with any given search entry going through each and every letter all characters
    from the beginning of the string"""
    search_text = search_entry.get().lower()

    # Clear the existing selection
    for item in tree.selection():
        tree.selection_remove(item)

    if search_text:
        matched_items = []  # List to store matched items
        # Iterate through treeview items
        for child in tree.get_children():
            values = [str(value).lower() for value in tree.item(child, 'values')]
            if any(value.startswith(search_text) for value in values):
                matched_items.append(child)  # Add matched item to the list
                tree.detach(child)  # Temporarily remove the item from the treeview

        # Reinsert matched items at the top of the treeview
        for idx, item in enumerate(matched_items):
            tree.move(item, '', idx)

        # Select all matched items
        for item in matched_items:
            tree.selection_add(item)

        # Deselect other items
        for child in tree.get_children():
            if child not in matched_items:
                tree.selection_remove(child)
    else:
        # If search text is empty, select all transactions
        for child in tree.get_children():
            tree.selection_add(child)


def transaction_tree_view(tree_frame, view_transaction_frame, transactions):
    """This function sets up the tree view using the loaded window widget arguments"""
    search_frame = Frame(view_transaction_frame, bg="black", padx=10, pady=10)
    search_frame.pack()

    search_label = Label(view_transaction_frame, text="Search:", font=("Arial", 20), bg="black")
    search_label.pack(side=LEFT)

    search_entry = Entry(view_transaction_frame, width=30, font=("Arial", 20), bg="white", fg="black")
    search_entry.pack(side=LEFT)
    search_entry.focus_set()

    search_button = Button(view_transaction_frame, text="Search", command=lambda: search_transactions(my_tree, search_entry), font=("Arial", 20))
    search_button.pack(side=LEFT)

    style = ttk.Style()

    # Clam is used to get th headings look like buttons
    style.theme_use("clam")

    # Configure our treeview colours and gridlines
    style.configure("Treeview", background="#c7c3c3", foreground="black", rowheight=30, fieldbackground="#c7c3c3", font=("Arial", 15), borderwidth=2, relief="sunken")
    style.map("Treeview", background=[("selected", "#347083")])
    style.configure("Treeview.Heading", font=("Arial", 18, "bold"))

    # Tree view scroll bar for when there are high level of transactions
    tree_scroll = Scrollbar(tree_frame)
    tree_scroll.pack(side=RIGHT, fill=Y)

    my_tree = ttk.Treeview(tree_frame, yscrollcommand=tree_scroll.set, selectmode="extended")

    my_tree.pack()

    # Configure the scroll bar
    tree_scroll.config(command=my_tree.yview)

    # Generate Headings to our columns
    my_tree["columns"] = ("Category", "Amount", "Transaction Type", "Date")

    # Format our columns
    my_tree.column("#0", width=0, stretch=NO)
    my_tree.column("Category", anchor=W, width=200, minwidth=150)
    my_tree.column("Amount", anchor=W, width=200, minwidth=150)
    my_tree.column("Transaction Type", anchor=W, width=200, minwidth=150)
    my_tree.column("Date", anchor=CENTER, width=200, minwidth=150)

    # Create Headings
    my_tree.heading("Category", text="Category", anchor=CENTER, command=lambda: sort_treeview(my_tree, "Category", "asc"))
    my_tree.heading("Amount", text="Amount", anchor=CENTER, command=lambda: sort_treeview(my_tree, "Amount", "asc"))
    my_tree.heading("Transaction Type", text="Transaction Type", anchor=CENTER, command=lambda: sort_treeview(my_tree, "Transaction Type", "asc"))
    my_tree.heading("Date", text="Date", anchor=CENTER, command=lambda: sort_treeview(my_tree, "Date", "asc"))

    count = 0  # count is set here for each transaction to have a unique iid

    # Insert transactions data into the treeview
    for category, transactions in transactions.items():
        for idx, transaction in enumerate(transactions, start=1):
            my_tree.insert("", "end", text=f"{category}-{idx}",iid=count, values=(category, transaction['Amount'], transaction['Transaction Type'], transaction['Date']))
            count += 1

    return my_tree


def check_field_entries(transaction_category_entry, transaction_amount_entry, transaction_year_entry, transaction_month_entry, transaction_day_entry, transaction_type, transaction_list, selected_field, event):
    """This function basically error checks entry field entries and check if it is usable to run the code
    .This function has various message boxes to show the user exactly what is happening"""
    global transactions

    category = transaction_category_entry.get().title()
    amount = transaction_amount_entry.get().title()
    year = transaction_year_entry.get().title()
    month = transaction_month_entry.get().title()
    day = transaction_day_entry.get().title()
    transaction_type = transaction_type.get()

    if selected_field:
        selected_field = int(selected_field)

    if category and amount and year and month and day:
        try:
            amount = float(amount)

            if amount <= 0:
                messagebox.showwarning(title="Warning", message="Transaction Value must be positive")
                transaction_amount_entry.delete(0, END)
                return

        except ValueError:
            messagebox.showwarning(title="Warning", message="Transaction Value must be numeric")
            transaction_amount_entry.delete(0, END)
            return

        try:
            year = int(year)
            if year < 1900 or year > 2100:
                messagebox.showwarning(title="Warning", message="Year must be between 1900 and 2100")
                transaction_year_entry.delete(0, END)
                return

        except ValueError:
            messagebox.showwarning(title="Warning", message="Year must be numeric and in 4 digits")
            transaction_year_entry.delete(0, END)
            return

        try:
            month = int(month)
            if month < 1 or month > 12:
                messagebox.showwarning(title="Warning", message="Month must be between 1 and 12")
                transaction_month_entry.delete(0, END)
                return

        except ValueError:
            messagebox.showwarning(title="Warning", message="Month must be numeric")
            transaction_month_entry.delete(0, END)
            return

        try:
            day = int(day)

            if month in (1, 3, 5, 7, 8, 10, 12):
                if day < 1 or day > 31:
                    messagebox.showwarning(title="Warning", message="Day must be between 1 and 31")
                    transaction_day_entry.delete(0, END)
                    return

            elif month in (4, 6, 9, 11):
                if day < 1 or day > 30:
                    messagebox.showwarning(title="Warning", message="Day must be between 1 and 30")
                    transaction_day_entry.delete(0, END)
                    return

            elif month == 2:
                if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
                    if day < 1 or day > 29:
                        messagebox.showwarning(title="Warning", message="Day must be between 1 and 29")
                        transaction_day_entry.delete(0, END)
                        return

                else:
                    if day < 1 or day > 28:
                        messagebox.showwarning(title="Warning", message="Day must be between 1 and 28")
                        transaction_day_entry.delete(0, END)
                        return

        except ValueError:
            messagebox.showwarning(title="Warning", message="Day must be numeric")
            transaction_day_entry.delete(0, END)
            return

    else:
        messagebox.showwarning("Error", "Please fill all fields")
        return

    transactions_dict = {
        "Amount": float("{:.2f}".format(amount)),
        "Transaction Type": str(transaction_type),
        "Date": "{}-{}-{}".format(str(year).zfill(4), str(month).zfill(2), str(day).zfill(2))
    }

    # for add and update the same function is used
    if event == "add":
        if category not in transactions:
            transactions[category] = [transactions_dict]

        else:
            transactions[category].append(transactions_dict)

    elif event == "update":

        update_transaction_list = transactions.get(transaction_list[selected_field][0], [])

        if category not in transactions:
            if len(update_transaction_list) == 1:
                del transactions[transaction_list[selected_field][0]]

            else:
                del transaction_list[selected_field]

                # To reconstruct the transactions dictionary for limited flexibility with dictionaries
                transactions = {}

                for record in transaction_list:
                    category_name = record[0]
                    transaction_dict = {"Amount": float(record[1]), "Transaction Type": record[2], "Date": record[3]}
                    transactions.setdefault(category_name, []).append(transaction_dict)

            transactions.setdefault(category, []).append(transactions_dict)

        else:
            # If the category matches the selected field, update the transaction
            if category == transaction_list[selected_field][0]:
                if len(transactions[category]) > 1:
                    del transaction_list[selected_field]
                    # Reconstruct the transactions dictionary without the selected field
                    transactions = {}

                    for record in transaction_list:
                        category_name = record[0]

                        transaction_dict = {"Amount": float(record[1]), "Transaction Type": record[2],
                                            "Date": record[3]}

                        transactions.setdefault(category_name, []).append(transaction_dict)

                    # Append the new transaction to the existing category
                    transactions[category].append(transactions_dict)
                else:
                    # If there is only one transaction in the category, update it directly
                    transactions[category] = [transactions_dict]

        # Save the updated transactions
        save_transactions(file_name)

        if event == "add":

            messagebox.showinfo(title="Success",
                                message="Transaction has been added")

            transaction_category_entry.delete(0, END)

            transaction_amount_entry.delete(0, END)

            transaction_year_entry.delete(0, END)

            transaction_month_entry.delete(0, END)

            transaction_day_entry.delete(0, END)

        elif event == "update":

            messagebox.showinfo(title="Success",
                                message="Transaction has been updated")

            update_transaction()

    save_transactions(file_name)

    if event == "add":
        messagebox.showinfo(title="Success",
                            message="Transaction has been added")
        transaction_category_entry.delete(0, END)
        transaction_amount_entry.delete(0, END)
        transaction_year_entry.delete(0, END)
        transaction_month_entry.delete(0, END)
        transaction_day_entry.delete(0, END)

    elif event == "update":
        messagebox.showinfo(title="Success",
                            message="Transaction has been updated")
        update_transaction()


def get_date(year_entry, month_entry, day_entry):
    """This function gets the current date from the datetime
    module and fills itself in the entry field"""
    # Populate the entry fields with the current date
    year_entry.delete(0, END)
    month_entry.delete(0, END)
    day_entry.delete(0, END)

    year_entry.insert(0, str(datetime.datetime.now().year).zfill(2))
    month_entry.insert(0, str(datetime.datetime.now().month).zfill(2))
    day_entry.insert(0, str(datetime.datetime.now().day).zfill(2))


def update_transaction_second_screen(selected_field):
    """This is a function to change the screen from one format to another
    since there is no space to keep entry fields in the first screen"""
    global transactions

    for widget in window.winfo_children():
        widget.destroy()

    transaction_list = []

    for category, transaction in transactions.items():
        for trans in transaction:
            amount = trans["Amount"]
            transaction_type = trans["Transaction Type"]
            date = trans["Date"]
            transaction_list.append([category, amount, transaction_type, date])

    updated_transaction_list = transaction_list.copy()

    # Create the exit button
    exit_photo = PhotoImage(file="Sub/Exit Icon.png")
    exit_button = Button(window,
                         text="Exit",
                         command=lambda: exit_gui(),
                         font=("Arial", 20),
                         bg="#666565",
                         fg="black",
                         padx=5,
                         pady=5,
                         image=exit_photo,
                         compound=LEFT)

    exit_button.image = exit_photo
    exit_button.pack(anchor=NW)

    update_transaction_frame = Frame(window,
                                     bg="black",
                                     pady=30,
                                     padx=20)
    update_transaction_frame.pack()

    title_label = Label(update_transaction_frame,
                        text="Enter the Transaction Information",
                        bg="black",
                        pady=60,
                        padx=20,
                        fg="silver",
                        font=("Arial", 40, "bold"))
    title_label.grid(row=0, column=0, columnspan=3, pady=10, padx=10)

    transaction_category_label = Label(update_transaction_frame,
                                       text="Transaction Category : ",
                                       width=25,
                                       fg="white",
                                       bg="black",
                                       font=("Arial", 20),
                                       pady=10,
                                       anchor=W)
    transaction_category_label.grid(row=1, column=0)

    transaction_category_entry = Entry(update_transaction_frame,
                                       width=40,
                                       fg="black",
                                       bg="white",
                                       font=("Arial", 20))
    transaction_category_entry.grid(row=1, column=1)
    transaction_category_entry.insert(0, transaction_list[int(selected_field)][0])
    transaction_category_entry.focus_set()

    transaction_amount_label = Label(update_transaction_frame,
                                     text="Transaction Value : ",
                                     width=25, fg="white",
                                     bg="black",
                                     font=("Arial", 20),
                                     pady=10,
                                     anchor=W)
    transaction_amount_label.grid(row=2, column=0)

    transaction_amount_entry = Entry(update_transaction_frame,
                                     width=40,
                                     fg="black",
                                     bg="white",
                                     font=("Arial", 20))
    transaction_amount_entry.grid(row=2, column=1)
    transaction_amount_entry.insert(0, transaction_list[int(selected_field)][1])
    transaction_amount_entry.focus_set()

    transaction_type_label = Label(update_transaction_frame,
                                   text="Transaction Type : ",
                                   width=25, fg="white",
                                   bg="black",
                                   font=("Arial", 20),
                                   pady=10,
                                   anchor=W)
    transaction_type_label.grid(row=3, column=0)

    # Pre-determined options for the dropdown menu
    options = ["Income", "Expense"]

    # Create a StringVar to store the selected option
    selected_option = StringVar()
    selected_option.set(transaction_list[int(selected_field)][2])

    # Create the OptionMenu widget
    transaction_type_menu = OptionMenu(update_transaction_frame, selected_option, *options)

    # Configure styling options
    transaction_type_menu.config(font=("Arial", 20),
                                 bg="white",
                                 fg="black",
                                 width=20,
                                 anchor=W,
                                 activeforeground="black",
                                 activebackground="light grey")

    # Position the OptionMenu widget
    transaction_type_menu.grid(row=3, column=1, padx=(3, 0), sticky=W)

    transaction_year_label = Label(update_transaction_frame,
                                   text="Year of Transaction : ",
                                   width=25,
                                   fg="white",
                                   bg="black",
                                   font=("Arial", 20),
                                   pady=10,
                                   anchor=W)
    transaction_year_label.grid(row=4, column=0)

    transaction_year_entry = Entry(update_transaction_frame,
                                   width=40,
                                   fg="black",
                                   bg="white",
                                   font=("Arial", 20))
    transaction_year_entry.grid(row=4, column=1)
    transaction_year_entry.insert(0, transaction_list[int(selected_field)][3][0:4])
    transaction_year_entry.focus_set()

    transaction_month_label = Label(update_transaction_frame,
                                    text="Month of Transaction : ",
                                    width=25,
                                    fg="white",
                                    bg="black",
                                    font=("Arial", 20),
                                    pady=10,
                                    anchor=W)
    transaction_month_label.grid(row=5, column=0)

    transaction_month_entry = Entry(update_transaction_frame,
                                    width=40,
                                    fg="black",
                                    bg="white",
                                    font=("Arial", 20))
    transaction_month_entry.grid(row=5, column=1)
    transaction_month_entry.insert(0, transaction_list[int(selected_field)][3][5:7])
    transaction_month_entry.focus_set()

    transaction_day_label = Label(update_transaction_frame,
                                  text="Day of Transaction : ",
                                  width=25,
                                  fg="white",
                                  bg="black",
                                  font=("Arial", 20),
                                  pady=10,
                                  anchor=W)
    transaction_day_label.grid(row=6, column=0)

    transaction_day_entry = Entry(update_transaction_frame,
                                  width=40,
                                  fg="black",
                                  bg="white",
                                  font=("Arial", 20))
    transaction_day_entry.grid(row=6, column=1)
    transaction_day_entry.insert(0, transaction_list[int(selected_field)][3][8:11])
    transaction_day_entry.focus_set()

    get_date_button = Button(update_transaction_frame,
                             text="Get Date Today",
                             command=lambda: get_date(transaction_year_entry,
                                                      transaction_month_entry,
                                                      transaction_day_entry),
                             bg="light grey",
                             fg="black",
                             font=("Arial", 20),
                             padx=5)
    get_date_button.grid(row=6, column=2)

    submit_button = Button(window,
                           text="Update Field",
                           font=("Arial", 20))
    submit_button.pack(pady=10)
    submit_button.bind("<Button>",
                       lambda event: check_field_entries(transaction_category_entry,
                                                         transaction_amount_entry,
                                                         transaction_year_entry,
                                                         transaction_month_entry,
                                                         transaction_day_entry,
                                                         selected_option,
                                                         transaction_list,
                                                         selected_field,
                                                         "update"))

    back_button = Button(window,
                         text="Back to Update Log Search",
                         command=lambda: update_transaction(),
                         font=("Arial", 20))
    back_button.pack(pady=10)



def add_transaction():
    """This transaction adds new transactions to the dictionary and
    calls the JSON file to using the save function to save at the end of the programme"""
    global transactions
    # To destroy all the widgets
    for widget in window.winfo_children():
        widget.destroy()

    # Create the exit button
    exit_photo = PhotoImage(file="Sub/Exit Icon.png")
    exit_button = Button(window, text="Exit",
                         command=lambda: exit_gui(),
                         font=("Arial", 20),
                         bg="#666565",
                         fg="black",
                         padx=5,
                         pady=5,
                         image=exit_photo,
                         compound=LEFT)
    exit_button.image = exit_photo
    exit_button.pack(anchor=NW)

    add_transaction_frame = Frame(window, bg="black", pady=30, padx=20)
    add_transaction_frame.pack()

    title_label = Label(add_transaction_frame,
                        text="Enter the Transaction Information",
                        bg="black",
                        pady=60,
                        padx=20,
                        fg="silver",
                        font=("Arial", 40, "bold"))
    title_label.grid(row=0, column=0, columnspan=3, pady=10, padx=10)

    transaction_category_label = Label(add_transaction_frame,
                                       text="Transaction Category : ",
                                       width=25,
                                       fg="white",
                                       bg="black",
                                       font=("Arial", 20),
                                       pady=10,
                                       anchor=W)
    transaction_category_label.grid(row=1, column=0)

    transaction_category_entry = Entry(add_transaction_frame,
                                       width=40,
                                       fg="black",
                                       bg="white",
                                       font=("Arial", 20))
    transaction_category_entry.grid(row=1, column=1)
    transaction_category_entry.focus_set()

    transaction_amount_label = Label(add_transaction_frame,
                                     text="Transaction Value : ",
                                     width=25,
                                     fg="white",
                                     bg="black",
                                     font=("Arial", 20),
                                     pady=10,
                                     anchor=W)
    transaction_amount_label.grid(row=2, column=0)

    transaction_amount_entry = Entry(add_transaction_frame,
                                     width=40,
                                     fg="black",
                                     bg="white",
                                     font=("Arial", 20))
    transaction_amount_entry.grid(row=2, column=1)
    transaction_amount_entry.focus_set()

    transaction_type_label = Label(add_transaction_frame,
                                   text="Transaction Type : ",
                                   width=25,
                                   fg="white",
                                   bg="black",
                                   font=("Arial", 20),
                                   pady=10,
                                   anchor=W)
    transaction_type_label.grid(row=3, column=0)

    # Define options for the dropdown menu
    options = ["Income", "Expense"]

    # Create a StringVar to store the selected option
    selected_option = StringVar()
    selected_option.set(options[1])  # Set default option

    # Create the OptionMenu widget
    transaction_type_menu = OptionMenu(add_transaction_frame,
                                       selected_option,
                                       *options)

    # Configure styling options
    transaction_type_menu.config(font=("Arial", 20),
                                 bg="white",
                                 fg="black",
                                 width=20,
                                 anchor=W,
                                 activeforeground="black",
                                 activebackground="light grey")

    # Position the OptionMenu widget
    transaction_type_menu.grid(row=3, column=1, padx=(3, 0), sticky=W)

    transaction_year_label = Label(add_transaction_frame,
                                   text="Year of Transaction : ",
                                   width=25,
                                   fg="white",
                                   bg="black",
                                   font=("Arial", 20),
                                   pady=10,
                                   anchor=W)
    transaction_year_label.grid(row=4, column=0)

    transaction_year_entry = Entry(add_transaction_frame,
                                   width=40,
                                   fg="black",
                                   bg="white",
                                   font=("Arial", 20))
    transaction_year_entry.grid(row=4, column=1)
    transaction_year_entry.focus_set()

    transaction_month_label = Label(add_transaction_frame,
                                    text="Month of Transaction : ",
                                    width=25,
                                    fg="white",
                                    bg="black",
                                    font=("Arial", 20),
                                    pady=10,
                                    anchor=W)
    transaction_month_label.grid(row=5, column=0)

    transaction_month_entry = Entry(add_transaction_frame,
                                    width=40,
                                    fg="black",
                                    bg="white",
                                    font=("Arial", 20))
    transaction_month_entry.grid(row=5, column=1)
    transaction_month_entry.focus_set()

    transaction_day_label = Label(add_transaction_frame,
                                  text="Day of Transaction : ",
                                  width=25,
                                  fg="white",
                                  bg="black",
                                  font=("Arial", 20),
                                  pady=10,
                                  anchor=W)
    transaction_day_label.grid(row=6, column=0)

    transaction_day_entry = Entry(add_transaction_frame,
                                  width=40,
                                  fg="black",
                                  bg="white",
                                  font=("Arial", 20))
    transaction_day_entry.grid(row=6, column=1)
    transaction_day_entry.focus_set()

    get_date_button = Button(add_transaction_frame,
                             text="Get Date Today",
                             command=lambda: get_date(transaction_year_entry,
                                                      transaction_month_entry,
                                                      transaction_day_entry),
                             bg="light grey",
                             fg="black",
                             font=("Arial", 20), padx=5)
    get_date_button.grid(row=6, column=2)

    submit_button = Button(window,
                           text="Submit",
                           font=("Arial", 20))
    submit_button.pack(pady=10)
    submit_button.bind("<Button>",
                       lambda event: check_field_entries(transaction_category_entry,
                                                         transaction_amount_entry,
                                                         transaction_year_entry,
                                                         transaction_month_entry,
                                                         transaction_day_entry,
                                                         selected_option,
                                                         None,
                                                         None,
                                                         "add"))

    back_button = Button(window,
                         text="Back to Main Menu",
                         command=lambda: main_menu(transactions),
                         font=("Arial", 20))
    back_button.pack(pady=10)


def delete_transaction():
    """This function deletes the selected transaction from the transactions dictionary"""
    global transactions
    global my_tree

    if not transactions:
        messagebox.showerror("Error", "No Transactions Found to Delete")
        return

    # To destroy all the widgets
    for widget in window.winfo_children():
        widget.destroy()

    # Create the exit button
    exit_photo = PhotoImage(file="Sub/Exit Icon.png")
    exit_button = Button(window,
                         text="Exit",
                         command=lambda: exit_gui(),
                         font=("Arial", 20),
                         bg="#666565",
                         fg="black",
                         padx=5,
                         pady=5,
                         image=exit_photo,
                         compound=LEFT)
    exit_button.image = exit_photo
    exit_button.pack(anchor=NW)

    delete_transaction_frame = Frame(window,
                                     bg="black",
                                     padx=10,
                                     pady=10)
    delete_transaction_frame.pack()

    tree_frame = Frame(window,
                       bg="black",
                       padx=10,
                       pady=10)
    tree_frame.pack()

    title_label = Label(delete_transaction_frame,
                        text="Transaction Deletion",
                        bg="black",
                        pady=60,
                        padx=20,
                        fg="silver",
                        font=("Arial", 40, "bold"))
    title_label.pack()

    my_tree = transaction_tree_view(tree_frame,
                                    delete_transaction_frame,
                                    transactions)

    delete_transaction_button = Button(window,
                                       text="Delete Selected Fields",
                                       command=lambda: delete_from_treeview(my_tree),
                                       font=("Arial", 20))
    delete_transaction_button.pack(pady=10)

    back_button = Button(window,
                         text="Back to Main Menu",
                         command=lambda: main_menu(transactions),
                         font=("Arial", 20))
    back_button.pack(pady=20)


def update_transaction():
    """This function updates the selected transaction from the transactions dictionary
    by calling another 2 transactions to function properly"""
    global transactions

    if not transactions:
        messagebox.showerror("Error", "No Transactions Found to Update")
        return

    # To destroy all the widgets
    for widget in window.winfo_children():
        widget.destroy()

    # Create the exit button
    exit_photo = PhotoImage(file="Sub/Exit Icon.png")
    exit_button = Button(window,
                         text="Exit",
                         command=lambda: exit_gui(),
                         font=("Arial", 20),
                         bg="#666565",
                         fg="black",
                         padx=5,
                         pady=5,
                         image=exit_photo,
                         compound=LEFT)
    exit_button.image = exit_photo
    exit_button.pack(anchor=NW)

    update_transaction_frame = Frame(window,
                                     bg="black",
                                     padx=10,
                                     pady=10)
    update_transaction_frame.pack()

    tree_frame = Frame(window,
                       bg="black",
                       padx=10,
                       pady=10)
    tree_frame.pack()

    title_label = Label(update_transaction_frame,
                        text="Transaction Update Log",
                        bg="black",
                        pady=60,
                        padx=20,
                        fg="silver",
                        font=("Arial", 40, "bold"))
    title_label.pack()

    my_tree = transaction_tree_view(tree_frame,
                                    update_transaction_frame,
                                    transactions)

    transaction_select_button = Button(window,
                                       text="Select Transaction to Update",
                                       command=lambda: update_transaction_second_screen(my_tree.selection()[0]),
                                       font=("Arial", 20),
                                       fg="black",
                                       bg="white")
    transaction_select_button.pack(pady=20)

    back_button = Button(window,
                         text="Back to Main Menu",
                         command=lambda: main_menu(transactions),
                         font=("Arial", 20))
    back_button.pack(pady=20)


def view_transactions():
    """This functinon shows all the transactions in the transactions dictionary"""
    global transactions

    if not transactions:
        messagebox.showinfo("Error", "No Transactions Found to View")
        return

    # To destroy all the widgets
    for widget in window.winfo_children():
        widget.destroy()

    # Create the exit button
    exit_photo = PhotoImage(file="Sub/Exit Icon.png")
    exit_button = Button(window,
                         text="Exit",
                         command=lambda: exit_gui(),
                         font=("Arial", 20),
                         bg="#666565",
                         fg="black",
                         padx=5,
                         pady=5,
                         image=exit_photo,
                         compound=LEFT)
    exit_button.image = exit_photo
    exit_button.pack(anchor=NW)

    view_transactions_frame = Frame(window,
                                    bg="black",
                                    padx=10,
                                    pady=10)
    view_transactions_frame.pack()

    tree_frame = Frame(window,
                       bg="black",
                       padx=10,
                       pady=10)
    tree_frame.pack()

    title_label = Label(view_transactions_frame,
                        text="Transaction Viewer",
                        bg="black",
                        pady=60,
                        padx=20,
                        fg="silver",
                        font=("Arial", 40, "bold"))
    title_label.pack()

    # Call transaction_tree_view to display the transaction tree
    transaction_tree_view(tree_frame,
                          view_transactions_frame,
                          transactions)

    back_button = Button(window,
                         text="Back to Main Menu",
                         command=lambda: main_menu(transactions),
                         font=("Arial", 20))
    back_button.pack(pady=10)


def transaction_summary():
    """This function shows all the transactions in the transactions dictionary and
    displays it in a summarized version"""
    global transactions

    if not transactions:
        messagebox.showinfo("Note", "No Transactions Found to summarize")
        return

    else:
        total_income = sum(transaction["Amount"] for key in transactions.values() for transaction in key if transaction["Transaction Type"] == "Income")
        total_expense = sum(transaction["Amount"] for key in transactions.values() for transaction in key if transaction["Transaction Type"] == "Expense")
        net_balance = total_income - total_expense

    # To destroy all the widgets
    for widget in window.winfo_children():
        widget.destroy()

    # Create the exit button
    exit_photo = PhotoImage(file="Sub/Exit Icon.png")
    exit_button = Button(window,
                         text="Exit",
                         command=lambda: exit_gui(),
                         font=("Arial", 20),
                         bg="#666565",
                         fg="black",
                         padx=5,
                         pady=5,
                         image=exit_photo,
                         compound=LEFT)
    exit_button.image = exit_photo
    exit_button.pack(anchor=NW)

    summary_frame = Frame(window,
                          bg="black",
                          padx=10,
                          pady=10)
    summary_frame.pack()

    title_label = Label(summary_frame,
                        text="Transaction Summary",
                        bg="black",
                        pady=60,
                        padx=20,
                        fg="silver",
                        font=("Arial", 60, "bold"))
    title_label.grid(row=0, column=0, columnspan=2)

    total_income_label = Label(summary_frame,
                               text="Total Income : ",
                               bg="black",
                               fg="white",
                               font=("Arial", 30),
                               pady=10)
    total_income_label.grid(row=1, column=0)

    total_income_amount = Label(summary_frame,
                                text=str(total_income),
                                bg="black",
                                fg="white",
                                font=("Arial", 30),
                                pady=10)
    total_income_amount.grid(row=1, column=1)

    total_expense_label = Label(summary_frame,
                                text="Total Expense : ",
                                bg="black",
                                fg="white",
                                font=("Arial", 30),
                                pady=10,)
    total_expense_label.grid(row=2, column=0)

    total_expense_amount = Label(summary_frame,
                                 text=str(total_expense),
                                 bg="black",
                                 fg="white",
                                 font=("Arial", 30),
                                 pady=10)
    total_expense_amount.grid(row=2, column=1)

    summary_label = Label(summary_frame,
                          text="Net Balance : ",
                          bg="black",
                          fg="white",
                          font=("Arial", 30, "bold"),
                          pady=10,)
    summary_label.grid(row=3, column=0)

    summary_amount = Label(summary_frame,
                           text="{:.2f}".format(net_balance),
                           bg="black",
                           fg="white",
                           font=("Arial", 30, "bold"),
                           pady=10)
    summary_amount.grid(row=3, column=1)

    back_button = Button(window,
                         text="Back to Main Menu",
                         command=lambda: main_menu(transactions),
                         font=("Arial", 30))
    back_button.pack(pady=40)


def bulk_read_transactions():
    """This function would open a file given from the main menu dialog box
    and loads it to the transactions dictionary after error checking.
    Please note that this transaction is built to carry 4 arguments"""
    global transactions

    filepath = filedialog.askopenfilename(title="Open File",
                                          filetypes=(("text files", "*.txt"),
                                                     ("all files", "*.*")))

    try:
        with open(filepath, "r") as textfile:
            transaction_list = textfile.read().split()
            new_transaction_list = []

            for word in transaction_list:
                for char in string.punctuation:
                    word = word.strip(char)

                if not word:
                    continue

                new_transaction_list.append(word)

            if len(new_transaction_list) % 4 != 0:
                messagebox.showwarning("Warning", "Number of entries per transaction is not 4")
                raise Exception("Number of entries per transaction is not 4")

            for i in range(int(len(new_transaction_list) / 4)):
                amount, transaction_type, date, category = None, None, None, None
                for j in range(4):
                    if new_transaction_list[j].count(".") == 1 or new_transaction_list[j].replace(".", "").replace(" ", "").isnumeric():
                        amount = float(new_transaction_list[j].replace(" ", ""))

                    elif new_transaction_list[j].replace(" ", "").title() == "Income" or new_transaction_list[
                        j].replace(" ", "").title() == "Expense":
                        transaction_type = new_transaction_list[j].replace(" ", "").title()

                    elif new_transaction_list[j][:2].isnumeric() and new_transaction_list[j][-1].isnumeric():
                        for ch in new_transaction_list[j]:
                            if not ch.isnumeric():
                                div_char = ch

                        date = new_transaction_list[j].replace(div_char, "-").replace(" ", "")

                    else:
                        category = new_transaction_list[j].replace(" ", "").title()

                    if amount and transaction_type and date and category:
                        bulk_transaction_dict = {"Amount": amount,
                                                 "Transaction Type": transaction_type,
                                                 "Date": date,
                                                 "Category": category}

                        if category not in transactions:
                            transactions[category] = [bulk_transaction_dict]

                        else:
                            transactions[category].append(bulk_transaction_dict)

                        del new_transaction_list[0:4]

        save_transactions(file_name)

        messagebox.showinfo("Success", "Transactions Imported Successfully")

    except Exception as e:
        messagebox.showerror("Error", str(e))


def main_menu(transactions):
    """This function acts as the main function calling and connecting all the other functions
    to run the program smoothly"""
    # To destroy all the widgets
    for widget in window.winfo_children():
        widget.destroy()

    # Create the exit button
    exit_photo = PhotoImage(file="Sub/Exit Icon.png")
    exit_button = Button(window,
                         text="Exit",
                         command=lambda: exit_gui(),
                         font=("Arial", 20),
                         bg="#666565",
                         fg="black",
                         padx=5,
                         pady=5,
                         image=exit_photo,
                         compound=LEFT)
    exit_button.image = exit_photo
    exit_button.pack(anchor=NW)

    # Photo image for window title icon
    label_photo = PhotoImage(file="Sub/Display Icon copy.png")

    label = Label(window,
                  text="Personal Finance Tracker",
                  font=("Arial", 70, "bold"),
                  fg="#BCC6CC",
                  bg="black",
                  bd=10,
                  padx=20,
                  pady=100,
                  image=label_photo,
                  compound="left")

    label.image = label_photo
    label.pack()

    frame1 = Frame(window, bg="black")

    frame1.pack()

    add_photo = PhotoImage(file="Sub/Add Transaction.png")

    add_button = Button(frame1,
                        text="Add Transaction",
                        command=lambda: add_transaction(),
                        font=("Arial", 30),
                        fg="black",
                        bg="#666565",
                        activeforeground="#2e2d2d",
                        activebackground="light grey",
                        # state="disabled")
                        image=add_photo,
                        compound="top",
                        width=275,
                        pady=5)

    add_button.image = add_photo

    add_button.pack(side=LEFT, padx=10, pady=20)

    update_photo = PhotoImage(file="Sub/Update Transaction.png")

    update_button = Button(frame1,
                           text="Update Transaction",
                           command=lambda: update_transaction(),
                           font=("Arial", 30),
                           fg="black",
                           bg="#666565",
                           activeforeground="#2e2d2d",
                           activebackground="light grey",
                           # state="disabled")
                           image=update_photo,
                           compound="top",
                           width=275,
                           pady=5)

    update_button.image = update_photo

    update_button.pack(side=LEFT, padx=10, pady=20)

    delete_photo = PhotoImage(file="Sub/Delete Transaction.png")

    delete_button = Button(frame1,
                           text="Delete Transaction",
                           command=lambda: delete_transaction(),
                           font=("Arial", 30),
                           fg="black",
                           bg="#666565",
                           activeforeground="#2e2d2d",
                           activebackground="light grey",
                           # state="disabled")
                           image=delete_photo,
                           compound="top",
                           width=275,
                           pady=5)

    delete_button.image = delete_photo

    delete_button.pack(side=LEFT, padx=10, pady=20)

    frame2 = Frame(window,
                   bg="black")

    frame2.pack()

    view_photo = PhotoImage(file="Sub/View Transaction.png")

    view_button = Button(frame2,
                         text="View Transactions",
                         command=lambda: view_transactions(),
                         font=("Arial", 30),
                         fg="black",
                         bg="#666565",
                         activeforeground="#2e2d2d",
                         activebackground="light grey",
                         # state="disabled")
                         image=view_photo,
                         compound="top",
                         width=275,
                         pady=5)

    view_button.image = view_photo

    view_button.pack(side=LEFT, padx=10)

    summary_photo = PhotoImage(file="Sub/Transaction Summary.png")

    summary_button = Button(frame2,
                            text="View Summary",
                            command=lambda: transaction_summary(),
                            font=("Arial", 30),
                            fg="black",
                            bg="#666565",
                            activeforeground="#2e2d2d",
                            activebackground="light grey",
                            # state="disabled")
                            image=summary_photo,
                            compound="top",
                            width=275,
                            pady=5)

    summary_button.image = summary_photo

    summary_button.pack(side=LEFT, padx=10)

    bulk_read_photo = PhotoImage(file="Sub/Bulk Read.png")

    bulk_read_button = Button(frame2,
                              text="Bulk Read",
                              command=lambda: bulk_read_transactions(),
                              font=("Arial", 30),
                              fg="black",
                              bg="#666565",
                              activeforeground="#2e2d2d",
                              activebackground="light grey",
                              # state="disabled")
                              image=bulk_read_photo,
                              compound="top",
                              width=275,
                              pady=5)

    bulk_read_button.image = bulk_read_photo

    bulk_read_button.pack(side=LEFT, padx=10)


window = Tk()
window.geometry('1250x1250')
window.title("Personal Finance Tracker")
transactions = load_transactions(file_name)

# Photo image to display in dock or in window title
icon = PhotoImage(file="Sub/Window Icon.png")
window.iconphoto(True, icon)

# Configuring window background to black
window.config(background="black")
main_menu(transactions)

window.mainloop()
